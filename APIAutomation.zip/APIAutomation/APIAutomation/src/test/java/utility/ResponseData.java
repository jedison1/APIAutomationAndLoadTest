package utility;

import static io.restassured.RestAssured.*;

import io.restassured.http.ContentType;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

import java.io.File;

import io.restassured.response.Response;

public class ResponseData {

	public static Response getRepsonseFromAPI(String url) {
		Response res = given().contentType(ContentType.JSON).when().get(url);
		return res;
	}

	
	public static Response getReponseFromCountriesAPI(String url) {
		return getRepsonseFromAPI(url);
	}

	
	public static String getCapitalFromCountriesAPI(Response response) {
		return response.getBody().jsonPath().get("capital[0]");
	}

	
	public static Response getBodyFromCapitalAPI(String url) {
		return getRepsonseFromAPI(url);
	}
	
	
	public static String getCurrencyCodeFromAPI(Response response) {
		return response.getBody().jsonPath().get("currencies[0].code[0]");
	}
	
	
	public static String getCurrencyCodeFromCountriesAPI(Response countryAPIResponse) {	
		return getCurrencyCodeFromAPI(countryAPIResponse);
	}

	
	public static String getCurrencyCodeFromCapitalAPI(Response capitalAPIResponse) {	
		return getCurrencyCodeFromAPI(capitalAPIResponse);
	}
	
}
