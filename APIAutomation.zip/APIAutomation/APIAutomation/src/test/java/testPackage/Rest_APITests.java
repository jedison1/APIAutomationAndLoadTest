package testPackage;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static utility.ResponseData.*;

public class Rest_APITests {
	Response countriesAPIRespones;
	final String countiesAPI = "https://restcountries.eu/rest/v2/all?fields=name;capital;currencies;latlng";
	Response capitalAPIResponse;
	Response capitalAPIResponseForInvalidCapital;
	final String schemaPath = "./src/test/resources/Schema/Schema1.json";
	final String invalidCapitalAPIURL = "https://restcountries.eu/rest/v2/capital/invalid?fields=name;capital;currencies;latlng;regionalBlocs";
	
	
	
	@BeforeTest
	public void getResponseFromCapitalAPI() {
		countriesAPIRespones = getReponseFromCountriesAPI(countiesAPI);
		String capital = getCapitalFromCountriesAPI(countriesAPIRespones);
		String capitalAPIURL = "https://restcountries.eu/rest/v2/capital/" + capital
				+ "?fields=name;capital;currencies;latlng;regionalBlocs";
		capitalAPIResponse = getBodyFromCapitalAPI(capitalAPIURL);
	}

	
	/*
	 * Validating the Status code for valid Capital
	 * Validating the schema of Country API
	 */
	@Test(priority = 0)
	public void statusCodeAndSchemaValidation() {
		int expStatusCode = capitalAPIResponse.getStatusCode();
		Assert.assertEquals(expStatusCode,200);
		capitalAPIResponse.then().body(matchesJsonSchema(new File(schemaPath)));
	}
	
	
	/*
	 * Validating the Currency code from Countries API & Country API for respective capital
	 */
	@Test(priority = 1)
	public void currencyCodeValidation() {
		String currencyCodeFromCountry=getCurrencyCodeFromCountriesAPI(countriesAPIRespones);
		String currencyCodeFromCapital=getCurrencyCodeFromCapitalAPI(capitalAPIResponse);
		Assert.assertEquals(currencyCodeFromCapital, currencyCodeFromCountry);
	}
	
	
	/*
	 * Validating the Error Status code for Invalid Capital
	 */
	@Test(priority = 2)
	public void statusCodeValidationForInvalidCapital() {	
		capitalAPIResponseForInvalidCapital = getBodyFromCapitalAPI(invalidCapitalAPIURL);
		int statusCode=capitalAPIResponseForInvalidCapital.getStatusCode();
		Assert.assertEquals(statusCode, 404);
	}
	
	
	/*
	 * Validating the Error message in response for Invalid Capital
	 */
	@Test(priority = 3,dependsOnMethods = "statusCodeValidationForInvalidCapital")
	public void errorMessageValidationForInvalidCapital() {	
		capitalAPIResponseForInvalidCapital = getBodyFromCapitalAPI(invalidCapitalAPIURL);
		String errorMessage=capitalAPIResponseForInvalidCapital.getBody().jsonPath().get("message");
		Assert.assertEquals(errorMessage, "Not Found");
	}
	

}
